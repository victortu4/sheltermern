const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const PetSchema = new mongoose.Schema({
    name: {
        type: String,
        
        required: [true, "Must be at least 3 characters"]
        
    },
    type:{
        type: String,
        required: [true, "Must be at least 3 characters"]
    },
    description:{
        type: String,
        required: [true, "Must be at least 3 characters"]
    }
}, {timestamps:true})

const Pet = mongoose.model("Pet", PetSchema);

module.exports = Pet;