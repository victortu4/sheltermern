const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost/belt_exam_db", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log("The mongoose been found"))
    .catch(err => console.log("I lost the mongoose", err));